import 'package:flutter/material.dart';
import 'package:flutter_project/navigasi.dart';

class MainPage extends StatelessWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(30),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Builder(builder: (context) {
            return ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const NavigationPage(),
                  ),
                );
              },
              child: const Text(
                'Navigasi Halaman',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            );
          }),
          const SizedBox(height: 20),
          Builder(builder: (context) {
            return ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, 'list-view');
              },
              child: const Text(
                'Menuju List View',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            );
          }),
          const SizedBox(height: 20),
          Builder(builder: (context) {
            return ElevatedButton(
              onPressed: () {
                AlertDialog alertDialog = AlertDialog(
                  title: const Text('Informasi!!'),
                  content: const Text('Ini adalah Alert Dialog'),
                  actions: [
                    TextButton(
                      child: const Text('Oke'),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                );
                showDialog(context: context, builder: (context) => alertDialog);
              },
              child: const Text(
                'Tampilkan Dialog',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            );
          }),
          const SizedBox(height: 20),
          Builder(builder: (context) {
            return ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, 'page-view');
              },
              child: const Text(
                'Menuju Page View',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18,
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}
